#الملف بحقوق سورس  تربون  @ADXG25
import asyncio
import random
from asyncio.exceptions import TimeoutError

from telethon import events
from telethon.errors.rpcerrorlist import YouBlockedUserError

from W_X_E1 import W_X_E1
from ..helpers.utils import reply_id


@W_X_E1.on(admin_cmd(outgoing=True, pattern="ريمكس$"))
async def jepvois(vois):
  rl = random.randint(3,267)
  url = f"https://t.me/REMIXv1/{rl}"
  await vois.client.send_file(vois.chat_id,url,caption="ⓜ︙ BY : @ADXG25 🎧",parse_mode="html")
  await vois.delete()
