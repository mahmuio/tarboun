from telethon import functions
from telethon.tl import functions
from telethon.tl.functions.channels import InviteToChannelRequest

from W_X_E1 import W_X_E1

from ..core.managers import edit_delete, edit_or_reply

@W_X_E1.on(admin_cmd(pattern="تاك(?: |$)(.*)"))
async def iq(W_X_E1):
    mentions = W_X_E1.text[8:]
    chat = await W_X_E1.get_input_chat()
    async for x in W_X_E1.client.iter_participants(chat, 200):
        mentions += f" \n🝳 ⦙ ⵧ〈[{x.first_name}](tg://user?id={x.id})〉"
    await W_X_E1.client.send_message(W_X_E1.chat_id, mentions)
    await W_X_E1.delete()
@W_X_E1.on(admin_cmd(pattern="تاك 150(?: |$)(.*)"))
async def iq(W_X_E1):
    mentions = W_X_E1.text[8:]
    chat = await W_X_E1.get_input_chat()
    async for x in W_X_E1.client.iter_participants(chat, 150):
        mentions += f" \n🝳 ⦙ ⵧ〈[{x.first_name}](tg://user?id={x.id})〉 \n"
    await W_X_E1.client.send_message(W_X_E1.chat_id, mentions)
    await W_X_E1.delete()
@W_X_E1.on(admin_cmd(pattern="تاك 100(?: |$)(.*)"))
async def iq(W_X_E1):
    mentions = W_X_E1.text[8:]
    chat = await W_X_E1.get_input_chat()
    async for x in W_X_E1.client.iter_participants(chat, 100):
        mentions += f" \n🝳 ⦙ ⵧ〈[{x.first_name}](tg://user?id={x.id})〉 \n"
    await W_X_E1.client.send_message(W_X_E1.chat_id, mentions)
    await W_X_E1.delete()
@W_X_E1.on(admin_cmd(pattern="تاك 50(?: |$)(.*)"))
async def iq(W_X_E1):
    mentions = W_X_E1.text[8:]
    chat = await W_X_E1.get_input_chat()
    async for x in W_X_E1.client.iter_participants(chat, 50):
        mentions += f" \n🝳 ⦙ ⵧ〈[{x.first_name}](tg://user?id={x.id})〉 \n"
    await W_X_E1.client.send_message(W_X_E1.chat_id, mentions)
    await W_X_E1.delete()
@W_X_E1.on(admin_cmd(pattern="تاك 10(?: |$)(.*)"))
async def iq(W_X_E1):
    mentions = W_X_E1.text[8:]
    chat = await W_X_E1.get_input_chat()
    async for x in W_X_E1.client.iter_participants(chat, 10):
        mentions += f" \n 🝳 ⦙ ⵧ〈[{x.first_name}](tg://user?id={x.id})〉 \n"
    await W_X_E1.client.send_message(W_X_E1.chat_id, mentions)
    await W_X_E1.delete()
