from W_X_E1 import *
from W_X_E1 import W_X_E1 
from ..sql_helper.globals import gvarstatus

@W_X_E1.on(admin_cmd(pattern="(ذاتية|ذاتيه)"))
async def dato(event):
    if not event.is_reply:
        return await event.edit("..")
    W_X_E1 = await event.get_reply_message()
    pic = await W_X_E1.download_media()
    await bot.send_file(
        "me",
        pic,
        caption=f"""
- تـم جـلب الصـورة بنجـاح ✓ 
- غير مبري الذمه اذا استخدمت الامر للابتزاز
- CH: @ADXG25 
- Dev: @W_X_E1 
  """,
    )
    await event.edit(" 🙂❤️ ")
