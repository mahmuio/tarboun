from W_X_E1 import BOTLOG, BOTLOG_CHATID, W_X_E1

from ..Config import Config
from ..core.inlinebot import *
